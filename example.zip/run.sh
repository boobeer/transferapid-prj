#!/usr/bin/env bash
git clone https://github.com/boobeer/transferapid-prj.git
cd ./transferapid-prj/transferapid
mvn clean package -DoutputDirectory=target/lib dependency:copy-dependencies
cd ./target
java -cp "./lib/*;transferapid-1.0-SNAPSHOT.jar" org.bbr.examples.App
