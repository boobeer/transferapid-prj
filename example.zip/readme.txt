Windows:
1) create any folder (for example c:/1/test)
2) put run.bat in the new folder and run (./run.bat)
Expected results - the repository is downloaded, project is built with 37 test succeed, application is started.


Linux:
1) create any folder (for example /c/1/test)
2) put run.sh in the new folder and run (/c/1/test/run.sh)
Expected results - the repository is downloaded, project is built with 37 test succeed, application is started.

An example request:
http://localhost:8282/transfer-api?action=Check&sender-account-id=8788787&recipient-account-id=111&transfer-type=2&payment-id=8534

Expected response:
{"message":"TRANSFER PROCESSED","sender":{"account":{"id":8788787}},"recipient":{"account":{"id":111}},"transfer":{"sender":{"account":{"id":8788787}},"recipient":{"account":{"id":111}}}}